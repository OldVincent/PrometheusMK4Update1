# Serial Port Utilities

## 简介

串口实用工具模块。该模块提供一些与串口相关的常用工具。
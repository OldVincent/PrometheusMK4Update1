#pragma once

#include "RawPicture.hpp"
#include "CameraDevice.hpp"
#include "AbstractAcquisitor.hpp"
#include "LambdaAcquisitor.hpp"

namespace RoboPioneers::Cameras::Galaxy
{}